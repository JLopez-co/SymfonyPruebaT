<?php

namespace SymplificaBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SymplificaBundle extends Bundle
{
}
