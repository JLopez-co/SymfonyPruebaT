<?php

/* SymplificaBundle:Empleado:EmpleadoAddView.html.twig */
class __TwigTemplate_a2d545da9170c7814cf6c919675001f28027f13ecc38ce1221e833634acf01f0 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "SymplificaBundle:Empleado:EmpleadoAddView.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'javaScripts' => array($this, 'block_javaScripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_99afb317dbcf9ae85ca17862e254a93801d7db93b11ad6ec541b2b6fdf2f3f4f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_99afb317dbcf9ae85ca17862e254a93801d7db93b11ad6ec541b2b6fdf2f3f4f->enter($__internal_99afb317dbcf9ae85ca17862e254a93801d7db93b11ad6ec541b2b6fdf2f3f4f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SymplificaBundle:Empleado:EmpleadoAddView.html.twig"));

        $__internal_6592587d51342a25ee3ec8b0e8a46102c7398f90ccc2e2b8de83adbd23da1baf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6592587d51342a25ee3ec8b0e8a46102c7398f90ccc2e2b8de83adbd23da1baf->enter($__internal_6592587d51342a25ee3ec8b0e8a46102c7398f90ccc2e2b8de83adbd23da1baf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SymplificaBundle:Empleado:EmpleadoAddView.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_99afb317dbcf9ae85ca17862e254a93801d7db93b11ad6ec541b2b6fdf2f3f4f->leave($__internal_99afb317dbcf9ae85ca17862e254a93801d7db93b11ad6ec541b2b6fdf2f3f4f_prof);

        
        $__internal_6592587d51342a25ee3ec8b0e8a46102c7398f90ccc2e2b8de83adbd23da1baf->leave($__internal_6592587d51342a25ee3ec8b0e8a46102c7398f90ccc2e2b8de83adbd23da1baf_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_326a86ae85cabce42a9055882358166062b209aeaa442665ab788c3f1ee4fa27 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_326a86ae85cabce42a9055882358166062b209aeaa442665ab788c3f1ee4fa27->enter($__internal_326a86ae85cabce42a9055882358166062b209aeaa442665ab788c3f1ee4fa27_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_9f0dd64abac79e0b286d6f886d95b5d9957bbce2711fabe833530ee8da3fdcc1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9f0dd64abac79e0b286d6f886d95b5d9957bbce2711fabe833530ee8da3fdcc1->enter($__internal_9f0dd64abac79e0b286d6f886d95b5d9957bbce2711fabe833530ee8da3fdcc1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " Symplifica-Empleador ";
        
        $__internal_9f0dd64abac79e0b286d6f886d95b5d9957bbce2711fabe833530ee8da3fdcc1->leave($__internal_9f0dd64abac79e0b286d6f886d95b5d9957bbce2711fabe833530ee8da3fdcc1_prof);

        
        $__internal_326a86ae85cabce42a9055882358166062b209aeaa442665ab788c3f1ee4fa27->leave($__internal_326a86ae85cabce42a9055882358166062b209aeaa442665ab788c3f1ee4fa27_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_0488dc1e0df60c12985fe80cb78a8c222b51ad704c76763952ea0dfbca704d81 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_0488dc1e0df60c12985fe80cb78a8c222b51ad704c76763952ea0dfbca704d81->enter($__internal_0488dc1e0df60c12985fe80cb78a8c222b51ad704c76763952ea0dfbca704d81_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_bb6038f1784d6a37435faaf56de2bb0c9dbae192dacd9dbe5b1c2176a52aa286 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bb6038f1784d6a37435faaf56de2bb0c9dbae192dacd9dbe5b1c2176a52aa286->enter($__internal_bb6038f1784d6a37435faaf56de2bb0c9dbae192dacd9dbe5b1c2176a52aa286_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "
    <div id=\"contentTable\">
      <label><h2>Agregar empleados</h2></label>
    <div class=\"col-md-10\">
    <table class=\"table-hover\" id=\"tableEmpleador\">
      <thead>
        <th>Nombre empleador</th>
        <th>cedula empleador</th>
        <th>Dirrecion empleador</th>
        <th></th>
      </thead>
      <tbody>
       ";
        // line 16
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["empleadores"] ?? $this->getContext($context, "empleadores")));
        foreach ($context['_seq'] as $context["_key"] => $context["empleador"]) {
            echo "   
        <tr>
          <td>";
            // line 18
            echo twig_escape_filter($this->env, $this->getAttribute($context["empleador"], "nombreCompleto", array()), "html", null, true);
            echo "</td>
          <td>";
            // line 19
            echo twig_escape_filter($this->env, $this->getAttribute($context["empleador"], "documentoIdentidad", array()), "html", null, true);
            echo "</td>
          <td>";
            // line 20
            echo twig_escape_filter($this->env, $this->getAttribute($context["empleador"], "dirrecion", array()), "html", null, true);
            echo "</td>
          <td>  <button type=\"button\" class=\"btnEmpleadorAgre\" value=\"";
            // line 21
            echo twig_escape_filter($this->env, $this->getAttribute($context["empleador"], "id", array()), "html", null, true);
            echo "\">Asignar empleados</button></td>
        </tr>
       ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['empleador'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 23
        echo " 
    </tbody>
  </table>
  </div>
 </div>

  <div id=\"contentUsu\" style=\"display:none\">
          <form class=\"col-md-12\">
        <h2>Agregar empleador</h2>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtNombre\">Nombre del empleado</label>
          <div class=\"col-md-6\">
            <input class=\"form-control inputs\" type=\"text\" name=\"txtNombre\" id=\"txtNombre\" value=\"\" placeholder=\"Ingrese el nombre completo del empleado\">
          </div>
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"selectSexo\">Sexo del empleado</label>
           <div class=\"col-md-6\">
 
          <select class=\"form-control \" name=\"selectSexo\" id=\"selectSexo\">
            <option value=\"A0\">Selecione</option>
            <option value=\"0\">Femenino</option>
            <option value=\"1\">Masculino</option>
          </select>
          </div>
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtCedula\">Cedula</label>
          <div class=\"col-md-6\">
            <input class=\"form-control inputs\" type=\"number\" name=\"txtCedula\" id=\"txtCedula\" value=\"\" placeholder=\"Ingrese la cedula del empleado\">
          
          </div>
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtTelefono\">Telefono</label>
           <div class=\"col-md-6\">
            <input class=\"form-control inputs\" type=\"number\" name=\"txtTelefono\" id=\"txtTelefono\" value=\"\" placeholder=\"Ingrese el telefono del empleador\">
          </div> 
        </div>

        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"selectTipoContrato\">Contratp del empleado</label>
          <div class=\"col-md-6\">
          <select class=\"form-control\" name=\"selectTipoContrato\" id=\"selectTipoContrato\">
            <option value=\"A0\">Selecione</option>
            ";
        // line 68
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["contratos"] ?? $this->getContext($context, "contratos")));
        foreach ($context['_seq'] as $context["_key"] => $context["contrato"]) {
            // line 69
            echo "              <option value=\"";
            echo twig_escape_filter($this->env, $this->getAttribute($context["contrato"], "id", array()), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $this->getAttribute($context["contrato"], "nombreContrato", array()), "html", null, true);
            echo "</option>
            ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['contrato'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 71
        echo "          </select>
        </div>
        </div>
        <div class=\"col-md-6\">
            </br><button type=\"button\" class=\"btn btn-success\" id=\"btnAgregarEmpleado\">Agregar empleado</button>
        </div>
      </form>
    </div>

  ";
        
        $__internal_bb6038f1784d6a37435faaf56de2bb0c9dbae192dacd9dbe5b1c2176a52aa286->leave($__internal_bb6038f1784d6a37435faaf56de2bb0c9dbae192dacd9dbe5b1c2176a52aa286_prof);

        
        $__internal_0488dc1e0df60c12985fe80cb78a8c222b51ad704c76763952ea0dfbca704d81->leave($__internal_0488dc1e0df60c12985fe80cb78a8c222b51ad704c76763952ea0dfbca704d81_prof);

    }

    // line 82
    public function block_javaScripts($context, array $blocks = array())
    {
        $__internal_c41d8730ba57c761738838d24e1b11d65e39177d7b733f8391d2534ae95144e5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c41d8730ba57c761738838d24e1b11d65e39177d7b733f8391d2534ae95144e5->enter($__internal_c41d8730ba57c761738838d24e1b11d65e39177d7b733f8391d2534ae95144e5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javaScripts"));

        $__internal_7c7852a9ca8d91d63f1812904fbc1542c387554fa969cebe6d2878fa89d127e3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7c7852a9ca8d91d63f1812904fbc1542c387554fa969cebe6d2878fa89d127e3->enter($__internal_7c7852a9ca8d91d63f1812904fbc1542c387554fa969cebe6d2878fa89d127e3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javaScripts"));

        // line 83
        echo "  ";
        $this->displayParentBlock("javaScripts", $context, $blocks);
        echo "
  <script src=\"";
        // line 84
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/symplifica/js/empleado.js"), "html", null, true);
        echo "\"> </script>
";
        
        $__internal_7c7852a9ca8d91d63f1812904fbc1542c387554fa969cebe6d2878fa89d127e3->leave($__internal_7c7852a9ca8d91d63f1812904fbc1542c387554fa969cebe6d2878fa89d127e3_prof);

        
        $__internal_c41d8730ba57c761738838d24e1b11d65e39177d7b733f8391d2534ae95144e5->leave($__internal_c41d8730ba57c761738838d24e1b11d65e39177d7b733f8391d2534ae95144e5_prof);

    }

    public function getTemplateName()
    {
        return "SymplificaBundle:Empleado:EmpleadoAddView.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  206 => 84,  201 => 83,  192 => 82,  173 => 71,  162 => 69,  158 => 68,  111 => 23,  102 => 21,  98 => 20,  94 => 19,  90 => 18,  83 => 16,  69 => 4,  60 => 3,  42 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig'%}
{% block title %} Symplifica-Empleador {% endblock%}
  {% block body%}

    <div id=\"contentTable\">
      <label><h2>Agregar empleados</h2></label>
    <div class=\"col-md-10\">
    <table class=\"table-hover\" id=\"tableEmpleador\">
      <thead>
        <th>Nombre empleador</th>
        <th>cedula empleador</th>
        <th>Dirrecion empleador</th>
        <th></th>
      </thead>
      <tbody>
       {%for empleador in empleadores%}   
        <tr>
          <td>{{empleador.nombreCompleto}}</td>
          <td>{{empleador.documentoIdentidad}}</td>
          <td>{{empleador.dirrecion}}</td>
          <td>  <button type=\"button\" class=\"btnEmpleadorAgre\" value=\"{{empleador.id}}\">Asignar empleados</button></td>
        </tr>
       {%endfor%} 
    </tbody>
  </table>
  </div>
 </div>

  <div id=\"contentUsu\" style=\"display:none\">
          <form class=\"col-md-12\">
        <h2>Agregar empleador</h2>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtNombre\">Nombre del empleado</label>
          <div class=\"col-md-6\">
            <input class=\"form-control inputs\" type=\"text\" name=\"txtNombre\" id=\"txtNombre\" value=\"\" placeholder=\"Ingrese el nombre completo del empleado\">
          </div>
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"selectSexo\">Sexo del empleado</label>
           <div class=\"col-md-6\">
 
          <select class=\"form-control \" name=\"selectSexo\" id=\"selectSexo\">
            <option value=\"A0\">Selecione</option>
            <option value=\"0\">Femenino</option>
            <option value=\"1\">Masculino</option>
          </select>
          </div>
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtCedula\">Cedula</label>
          <div class=\"col-md-6\">
            <input class=\"form-control inputs\" type=\"number\" name=\"txtCedula\" id=\"txtCedula\" value=\"\" placeholder=\"Ingrese la cedula del empleado\">
          
          </div>
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtTelefono\">Telefono</label>
           <div class=\"col-md-6\">
            <input class=\"form-control inputs\" type=\"number\" name=\"txtTelefono\" id=\"txtTelefono\" value=\"\" placeholder=\"Ingrese el telefono del empleador\">
          </div> 
        </div>

        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"selectTipoContrato\">Contratp del empleado</label>
          <div class=\"col-md-6\">
          <select class=\"form-control\" name=\"selectTipoContrato\" id=\"selectTipoContrato\">
            <option value=\"A0\">Selecione</option>
            {%for contrato in contratos %}
              <option value=\"{{contrato.id}}\">{{contrato.nombreContrato}}</option>
            {%endfor%}
          </select>
        </div>
        </div>
        <div class=\"col-md-6\">
            </br><button type=\"button\" class=\"btn btn-success\" id=\"btnAgregarEmpleado\">Agregar empleado</button>
        </div>
      </form>
    </div>

  {%endblock%}

{%block javaScripts%}
  {{parent()}}
  <script src=\"{{asset('bundles/symplifica/js/empleado.js')}}\"> </script>
{%endblock%}
", "SymplificaBundle:Empleado:EmpleadoAddView.html.twig", "/opt/lampp/htdocs/SymfonyPruebaT/symplifica/src/SymplificaBundle/Resources/views/Empleado/EmpleadoAddView.html.twig");
    }
}
