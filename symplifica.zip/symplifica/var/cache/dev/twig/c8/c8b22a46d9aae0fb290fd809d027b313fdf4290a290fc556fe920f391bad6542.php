<?php

/* base.html.twig */
class __TwigTemplate_47fd51b039e5f4fb7e336b9f260737cefed48cbce97d781ee1d74e5c39c4c062 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cce6a8ab826127df8870828b8e169c1ec7ddb908122d442b2bbb3fe1c39cde47 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cce6a8ab826127df8870828b8e169c1ec7ddb908122d442b2bbb3fe1c39cde47->enter($__internal_cce6a8ab826127df8870828b8e169c1ec7ddb908122d442b2bbb3fe1c39cde47_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_c874d931b942c8149e073eeb641504eddeb577783a7c4cf0a6cbc52dbd938da3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c874d931b942c8149e073eeb641504eddeb577783a7c4cf0a6cbc52dbd938da3->enter($__internal_c874d931b942c8149e073eeb641504eddeb577783a7c4cf0a6cbc52dbd938da3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 13
        $this->displayBlock('body', $context, $blocks);
        // line 14
        echo "            <script src=\"asset('public/js/jquery.js')\"> </script>
        ";
        // line 15
        $this->displayBlock('javascripts', $context, $blocks);
        // line 16
        echo "    </body>
</html>
";
        
        $__internal_cce6a8ab826127df8870828b8e169c1ec7ddb908122d442b2bbb3fe1c39cde47->leave($__internal_cce6a8ab826127df8870828b8e169c1ec7ddb908122d442b2bbb3fe1c39cde47_prof);

        
        $__internal_c874d931b942c8149e073eeb641504eddeb577783a7c4cf0a6cbc52dbd938da3->leave($__internal_c874d931b942c8149e073eeb641504eddeb577783a7c4cf0a6cbc52dbd938da3_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_3f75c61cfd90c7e1b89ff1cf70a85e2ed2e7207d0bb6d830996a9ee833df7117 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_3f75c61cfd90c7e1b89ff1cf70a85e2ed2e7207d0bb6d830996a9ee833df7117->enter($__internal_3f75c61cfd90c7e1b89ff1cf70a85e2ed2e7207d0bb6d830996a9ee833df7117_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_98fcdb797a6cfe4e29ca165a8d775e44df3fbbccf75db0b38a82ceff03ab6361 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_98fcdb797a6cfe4e29ca165a8d775e44df3fbbccf75db0b38a82ceff03ab6361->enter($__internal_98fcdb797a6cfe4e29ca165a8d775e44df3fbbccf75db0b38a82ceff03ab6361_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Symplifica";
        
        $__internal_98fcdb797a6cfe4e29ca165a8d775e44df3fbbccf75db0b38a82ceff03ab6361->leave($__internal_98fcdb797a6cfe4e29ca165a8d775e44df3fbbccf75db0b38a82ceff03ab6361_prof);

        
        $__internal_3f75c61cfd90c7e1b89ff1cf70a85e2ed2e7207d0bb6d830996a9ee833df7117->leave($__internal_3f75c61cfd90c7e1b89ff1cf70a85e2ed2e7207d0bb6d830996a9ee833df7117_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_7f8d155b2faddea6dd03ce9279befed7f350465fb28f39ba6bb9f14f63fd0553 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_7f8d155b2faddea6dd03ce9279befed7f350465fb28f39ba6bb9f14f63fd0553->enter($__internal_7f8d155b2faddea6dd03ce9279befed7f350465fb28f39ba6bb9f14f63fd0553_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_45998479483c975377a98c703b6e642fe1c43be623925085ec397c3217f2b5a7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_45998479483c975377a98c703b6e642fe1c43be623925085ec397c3217f2b5a7->enter($__internal_45998479483c975377a98c703b6e642fe1c43be623925085ec397c3217f2b5a7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "            <link href=\"asset('public/css/bootstrap.min.css')\">

        ";
        
        $__internal_45998479483c975377a98c703b6e642fe1c43be623925085ec397c3217f2b5a7->leave($__internal_45998479483c975377a98c703b6e642fe1c43be623925085ec397c3217f2b5a7_prof);

        
        $__internal_7f8d155b2faddea6dd03ce9279befed7f350465fb28f39ba6bb9f14f63fd0553->leave($__internal_7f8d155b2faddea6dd03ce9279befed7f350465fb28f39ba6bb9f14f63fd0553_prof);

    }

    // line 13
    public function block_body($context, array $blocks = array())
    {
        $__internal_6136858071422ed4ad9c0306636bd107f6584d497214c4bc74f958c05a1c5f2f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6136858071422ed4ad9c0306636bd107f6584d497214c4bc74f958c05a1c5f2f->enter($__internal_6136858071422ed4ad9c0306636bd107f6584d497214c4bc74f958c05a1c5f2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_3d274d8684da2f87f600337d1dff3bd2fe436de9c4245f579b9daac53a38c201 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_3d274d8684da2f87f600337d1dff3bd2fe436de9c4245f579b9daac53a38c201->enter($__internal_3d274d8684da2f87f600337d1dff3bd2fe436de9c4245f579b9daac53a38c201_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_3d274d8684da2f87f600337d1dff3bd2fe436de9c4245f579b9daac53a38c201->leave($__internal_3d274d8684da2f87f600337d1dff3bd2fe436de9c4245f579b9daac53a38c201_prof);

        
        $__internal_6136858071422ed4ad9c0306636bd107f6584d497214c4bc74f958c05a1c5f2f->leave($__internal_6136858071422ed4ad9c0306636bd107f6584d497214c4bc74f958c05a1c5f2f_prof);

    }

    // line 15
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_9ae08c3338e1144e3b20826c087309c2c8893458b9a25155ef99cce5f2a5e116 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9ae08c3338e1144e3b20826c087309c2c8893458b9a25155ef99cce5f2a5e116->enter($__internal_9ae08c3338e1144e3b20826c087309c2c8893458b9a25155ef99cce5f2a5e116_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_a0403b2e21a835aa33e99596b5286204db6bdfce570aab337a1a409992fdb174 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_a0403b2e21a835aa33e99596b5286204db6bdfce570aab337a1a409992fdb174->enter($__internal_a0403b2e21a835aa33e99596b5286204db6bdfce570aab337a1a409992fdb174_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_a0403b2e21a835aa33e99596b5286204db6bdfce570aab337a1a409992fdb174->leave($__internal_a0403b2e21a835aa33e99596b5286204db6bdfce570aab337a1a409992fdb174_prof);

        
        $__internal_9ae08c3338e1144e3b20826c087309c2c8893458b9a25155ef99cce5f2a5e116->leave($__internal_9ae08c3338e1144e3b20826c087309c2c8893458b9a25155ef99cce5f2a5e116_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  123 => 15,  106 => 13,  94 => 7,  85 => 6,  67 => 5,  55 => 16,  53 => 15,  50 => 14,  48 => 13,  41 => 10,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Symplifica{% endblock %}</title>
        {% block stylesheets %}
            <link href=\"asset('public/css/bootstrap.min.css')\">

        {% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
            <script src=\"asset('public/js/jquery.js')\"> </script>
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "base.html.twig", "/opt/lampp/htdocs/SymfonyPruebaT/symplifica/app/Resources/views/base.html.twig");
    }
}
