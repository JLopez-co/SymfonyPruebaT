<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_ff745af4c9785908df5f50f3220a611a7a8150c8acb4b2d4fa58002236a15742 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_fe0f196e322a075481449219ed1d4bec922a81f547e59e3c0d57e762d396f4da = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fe0f196e322a075481449219ed1d4bec922a81f547e59e3c0d57e762d396f4da->enter($__internal_fe0f196e322a075481449219ed1d4bec922a81f547e59e3c0d57e762d396f4da_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_6f2f164c29fd80563a7cea1e3127f754e1942e7278412a32cca78d86f4445dac = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_6f2f164c29fd80563a7cea1e3127f754e1942e7278412a32cca78d86f4445dac->enter($__internal_6f2f164c29fd80563a7cea1e3127f754e1942e7278412a32cca78d86f4445dac_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_fe0f196e322a075481449219ed1d4bec922a81f547e59e3c0d57e762d396f4da->leave($__internal_fe0f196e322a075481449219ed1d4bec922a81f547e59e3c0d57e762d396f4da_prof);

        
        $__internal_6f2f164c29fd80563a7cea1e3127f754e1942e7278412a32cca78d86f4445dac->leave($__internal_6f2f164c29fd80563a7cea1e3127f754e1942e7278412a32cca78d86f4445dac_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_46245571538f23f63ac8aed17db39dbf16aa9176a82294ed56e0de709a4aabc4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_46245571538f23f63ac8aed17db39dbf16aa9176a82294ed56e0de709a4aabc4->enter($__internal_46245571538f23f63ac8aed17db39dbf16aa9176a82294ed56e0de709a4aabc4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_50cfa38fa536116ff037f1e500fe5cea64c894bccca8c3363aaad439bc15d574 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_50cfa38fa536116ff037f1e500fe5cea64c894bccca8c3363aaad439bc15d574->enter($__internal_50cfa38fa536116ff037f1e500fe5cea64c894bccca8c3363aaad439bc15d574_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_50cfa38fa536116ff037f1e500fe5cea64c894bccca8c3363aaad439bc15d574->leave($__internal_50cfa38fa536116ff037f1e500fe5cea64c894bccca8c3363aaad439bc15d574_prof);

        
        $__internal_46245571538f23f63ac8aed17db39dbf16aa9176a82294ed56e0de709a4aabc4->leave($__internal_46245571538f23f63ac8aed17db39dbf16aa9176a82294ed56e0de709a4aabc4_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_ac5e7a0317ffa63d331807d0fbe9727c09dbe10077bfa701bc94bc46ccf63d69 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ac5e7a0317ffa63d331807d0fbe9727c09dbe10077bfa701bc94bc46ccf63d69->enter($__internal_ac5e7a0317ffa63d331807d0fbe9727c09dbe10077bfa701bc94bc46ccf63d69_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_ba8a95d3c4c6d419faef0d8f793046e7b31254e6500bafb9a703a1f3bc02f6f6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ba8a95d3c4c6d419faef0d8f793046e7b31254e6500bafb9a703a1f3bc02f6f6->enter($__internal_ba8a95d3c4c6d419faef0d8f793046e7b31254e6500bafb9a703a1f3bc02f6f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_ba8a95d3c4c6d419faef0d8f793046e7b31254e6500bafb9a703a1f3bc02f6f6->leave($__internal_ba8a95d3c4c6d419faef0d8f793046e7b31254e6500bafb9a703a1f3bc02f6f6_prof);

        
        $__internal_ac5e7a0317ffa63d331807d0fbe9727c09dbe10077bfa701bc94bc46ccf63d69->leave($__internal_ac5e7a0317ffa63d331807d0fbe9727c09dbe10077bfa701bc94bc46ccf63d69_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_d7d3a8e1389d373bb4b9f708509864cd20c670045bfc6e7a863d152a66dee34d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d7d3a8e1389d373bb4b9f708509864cd20c670045bfc6e7a863d152a66dee34d->enter($__internal_d7d3a8e1389d373bb4b9f708509864cd20c670045bfc6e7a863d152a66dee34d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_c524f401775b145535a869e2c5e718ac4c32cefff681169215211aa666770a63 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c524f401775b145535a869e2c5e718ac4c32cefff681169215211aa666770a63->enter($__internal_c524f401775b145535a869e2c5e718ac4c32cefff681169215211aa666770a63_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_c524f401775b145535a869e2c5e718ac4c32cefff681169215211aa666770a63->leave($__internal_c524f401775b145535a869e2c5e718ac4c32cefff681169215211aa666770a63_prof);

        
        $__internal_d7d3a8e1389d373bb4b9f708509864cd20c670045bfc6e7a863d152a66dee34d->leave($__internal_d7d3a8e1389d373bb4b9f708509864cd20c670045bfc6e7a863d152a66dee34d_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "/opt/lampp/htdocs/SymfonyPruebaT/symplifica/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/exception.html.twig");
    }
}
