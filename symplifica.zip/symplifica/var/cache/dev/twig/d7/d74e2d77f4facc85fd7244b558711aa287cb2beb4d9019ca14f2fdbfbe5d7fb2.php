<?php

/* SymplificaBundle:Default:index.html.twig */
class __TwigTemplate_470e56d615a26101d69ca191735c21d8077feadeb3add76b1463015b7b7c5fde extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12b4ebdab3af50cb9811ba5e6cbbba5b221bb91e0d309cd4708ed2c2514fd8d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12b4ebdab3af50cb9811ba5e6cbbba5b221bb91e0d309cd4708ed2c2514fd8d5->enter($__internal_12b4ebdab3af50cb9811ba5e6cbbba5b221bb91e0d309cd4708ed2c2514fd8d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SymplificaBundle:Default:index.html.twig"));

        $__internal_8368e12f505546a9ba9a5fede84a48c3c2611fd9a20521183b0b9c45e6b8b943 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8368e12f505546a9ba9a5fede84a48c3c2611fd9a20521183b0b9c45e6b8b943->enter($__internal_8368e12f505546a9ba9a5fede84a48c3c2611fd9a20521183b0b9c45e6b8b943_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SymplificaBundle:Default:index.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"utf-8\">
    <title>Symplifica-menu</title>
  </head>
  <body>
      <article class=\"col-md-12\">
        <label >Menu</label></br>
        <a href=\"";
        // line 10
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("symplifica_empleador");
        echo "\">Creación de empleador</a> </br>
         <a href=\"";
        // line 11
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("symplifica_empleado");
        echo "\">Creación de empleado</a> </br>
          <a href=\"";
        // line 12
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("symplifica_reporte");
        echo "\">Reporte</a>

      </article>
  </body>
</html>";
        
        $__internal_12b4ebdab3af50cb9811ba5e6cbbba5b221bb91e0d309cd4708ed2c2514fd8d5->leave($__internal_12b4ebdab3af50cb9811ba5e6cbbba5b221bb91e0d309cd4708ed2c2514fd8d5_prof);

        
        $__internal_8368e12f505546a9ba9a5fede84a48c3c2611fd9a20521183b0b9c45e6b8b943->leave($__internal_8368e12f505546a9ba9a5fede84a48c3c2611fd9a20521183b0b9c45e6b8b943_prof);

    }

    public function getTemplateName()
    {
        return "SymplificaBundle:Default:index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  44 => 12,  40 => 11,  36 => 10,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
  <head>
    <meta charset=\"utf-8\">
    <title>Symplifica-menu</title>
  </head>
  <body>
      <article class=\"col-md-12\">
        <label >Menu</label></br>
        <a href=\"{{path('symplifica_empleador')}}\">Creación de empleador</a> </br>
         <a href=\"{{path('symplifica_empleado')}}\">Creación de empleado</a> </br>
          <a href=\"{{path('symplifica_reporte')}}\">Reporte</a>

      </article>
  </body>
</html>", "SymplificaBundle:Default:index.html.twig", "/opt/lampp/htdocs/SymfonyPruebaT/symplifica/src/SymplificaBundle/Resources/views/Default/index.html.twig");
    }
}
