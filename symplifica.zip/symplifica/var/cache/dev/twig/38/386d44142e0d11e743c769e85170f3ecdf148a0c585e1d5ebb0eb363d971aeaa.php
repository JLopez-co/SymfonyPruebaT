<?php

/* SymplificaBundle:Empleador:EmpleadorAddView.html.twig */
class __TwigTemplate_d21478c521154423137d9e7f1e455e217c6ed791815e8b7b8a4a27576ace15ce extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "SymplificaBundle:Empleador:EmpleadorAddView.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
            'javaScripts' => array($this, 'block_javaScripts'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_5ce40bf7abf80c18bb6468cde8d640d1663560114231b03e9df8a4e39147ec6b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_5ce40bf7abf80c18bb6468cde8d640d1663560114231b03e9df8a4e39147ec6b->enter($__internal_5ce40bf7abf80c18bb6468cde8d640d1663560114231b03e9df8a4e39147ec6b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SymplificaBundle:Empleador:EmpleadorAddView.html.twig"));

        $__internal_91bc3d195463f5a90e0b24ae2aef3d2162cd8842d8d1be526472f87189fa8ddc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_91bc3d195463f5a90e0b24ae2aef3d2162cd8842d8d1be526472f87189fa8ddc->enter($__internal_91bc3d195463f5a90e0b24ae2aef3d2162cd8842d8d1be526472f87189fa8ddc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SymplificaBundle:Empleador:EmpleadorAddView.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_5ce40bf7abf80c18bb6468cde8d640d1663560114231b03e9df8a4e39147ec6b->leave($__internal_5ce40bf7abf80c18bb6468cde8d640d1663560114231b03e9df8a4e39147ec6b_prof);

        
        $__internal_91bc3d195463f5a90e0b24ae2aef3d2162cd8842d8d1be526472f87189fa8ddc->leave($__internal_91bc3d195463f5a90e0b24ae2aef3d2162cd8842d8d1be526472f87189fa8ddc_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_34411fec361506585d694241d561cc5b135fbdc8a2f6de169221381ca7633f28 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_34411fec361506585d694241d561cc5b135fbdc8a2f6de169221381ca7633f28->enter($__internal_34411fec361506585d694241d561cc5b135fbdc8a2f6de169221381ca7633f28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_241b33f0b198ca7ab87216eee1735cc6fbbecc6dd391488563b25115d2172152 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_241b33f0b198ca7ab87216eee1735cc6fbbecc6dd391488563b25115d2172152->enter($__internal_241b33f0b198ca7ab87216eee1735cc6fbbecc6dd391488563b25115d2172152_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " Symplifica-Empleador ";
        
        $__internal_241b33f0b198ca7ab87216eee1735cc6fbbecc6dd391488563b25115d2172152->leave($__internal_241b33f0b198ca7ab87216eee1735cc6fbbecc6dd391488563b25115d2172152_prof);

        
        $__internal_34411fec361506585d694241d561cc5b135fbdc8a2f6de169221381ca7633f28->leave($__internal_34411fec361506585d694241d561cc5b135fbdc8a2f6de169221381ca7633f28_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_503c2db5314f6cf57fc6bbf74baf505a8c20a14d2ca47ca5807407b03501ca5f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_503c2db5314f6cf57fc6bbf74baf505a8c20a14d2ca47ca5807407b03501ca5f->enter($__internal_503c2db5314f6cf57fc6bbf74baf505a8c20a14d2ca47ca5807407b03501ca5f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_453c5a60c0139c67479edacad4239ad15f7154b070fc19b32ee751c869242573 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_453c5a60c0139c67479edacad4239ad15f7154b070fc19b32ee751c869242573->enter($__internal_453c5a60c0139c67479edacad4239ad15f7154b070fc19b32ee751c869242573_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "        <form class=\"col-md-12\">
        <h2>Agregar empleador</h2>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtNombre\">Nombre del empleador</label>
          <input class=\"col-md-6 \" type=\"text\" name=\"txtNombre\" id=\"txtNombre\" value=\"\" placeholder=\"Ingrese el nombre completo del empleador\" requiere>
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"selectSexo\">Sexo del empleador</label>
          <select class=\"col-md-6\" name=\"selectSexo\" id=\"selectSexo\">
            <option value=\"A0\">Selecione</option>
            <option value=\"0\">Femenino</option>
            <option value=\"1\">Masculino</option>
          </select>
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtCedula\">Cedula</label>
          <input class=\"col-md-6 \" type=\"number\" name=\"txtCedula\" id=\"txtCedula\" value=\"\" placeholder=\"Ingrese la cedula del empleador\">
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtTelefono\">Telefono</label>
          <input class=\"col-md-6\" type=\"number\" name=\"txtTelefono\" id=\"txtTelefono\" value=\"\" placeholder=\"Ingrese el telefono del empleador\">
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtDirrecion\">Dirrecion</label>
          <input class=\"col-md-6 \" type=\"text\" name=\"txtDirrecion\" id=\"txtDirrecion\" value=\"\" placeholder=\"Ingrese la dirrecion del empleador\">
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtFechaNacimiento\">Fecha nacimiento</label>
          <input class=\"col-md-6 \" type=\"date\" name=\"txtFechaNacimiento\" id=\"txtFechaNacimiento\" value=\"\" placeholder=\"Ingrese la fecha de nacimiento del empleador\"> 
  
        </div>
        <div class=\"col-md-6\">
            </br><button type=\"button\" class=\"btn btn-success\" id=\"btnAgregarEmpleador\">Agregar empleador</button>
        </div>
      </form>
  ";
        
        $__internal_453c5a60c0139c67479edacad4239ad15f7154b070fc19b32ee751c869242573->leave($__internal_453c5a60c0139c67479edacad4239ad15f7154b070fc19b32ee751c869242573_prof);

        
        $__internal_503c2db5314f6cf57fc6bbf74baf505a8c20a14d2ca47ca5807407b03501ca5f->leave($__internal_503c2db5314f6cf57fc6bbf74baf505a8c20a14d2ca47ca5807407b03501ca5f_prof);

    }

    // line 40
    public function block_javaScripts($context, array $blocks = array())
    {
        $__internal_a2c2cdf3fa7b20eccef8778126363f3b4314e0c171a1cd3512fcd567cce8ad3d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a2c2cdf3fa7b20eccef8778126363f3b4314e0c171a1cd3512fcd567cce8ad3d->enter($__internal_a2c2cdf3fa7b20eccef8778126363f3b4314e0c171a1cd3512fcd567cce8ad3d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javaScripts"));

        $__internal_bcfc3daa2ad2e63a44ad58d249c73df8d8a5f460676cd690062c954194b7f7ce = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_bcfc3daa2ad2e63a44ad58d249c73df8d8a5f460676cd690062c954194b7f7ce->enter($__internal_bcfc3daa2ad2e63a44ad58d249c73df8d8a5f460676cd690062c954194b7f7ce_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javaScripts"));

        // line 41
        echo "  ";
        $this->displayParentBlock("javaScripts", $context, $blocks);
        echo "
  <script src=\"";
        // line 42
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("bundles/symplifica/js/empleador.js"), "html", null, true);
        echo "\"> </script>

";
        
        $__internal_bcfc3daa2ad2e63a44ad58d249c73df8d8a5f460676cd690062c954194b7f7ce->leave($__internal_bcfc3daa2ad2e63a44ad58d249c73df8d8a5f460676cd690062c954194b7f7ce_prof);

        
        $__internal_a2c2cdf3fa7b20eccef8778126363f3b4314e0c171a1cd3512fcd567cce8ad3d->leave($__internal_a2c2cdf3fa7b20eccef8778126363f3b4314e0c171a1cd3512fcd567cce8ad3d_prof);

    }

    public function getTemplateName()
    {
        return "SymplificaBundle:Empleador:EmpleadorAddView.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  128 => 42,  123 => 41,  114 => 40,  69 => 4,  60 => 3,  42 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig'%}
{% block title %} Symplifica-Empleador {% endblock%}
  {% block body%}
        <form class=\"col-md-12\">
        <h2>Agregar empleador</h2>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtNombre\">Nombre del empleador</label>
          <input class=\"col-md-6 \" type=\"text\" name=\"txtNombre\" id=\"txtNombre\" value=\"\" placeholder=\"Ingrese el nombre completo del empleador\" requiere>
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"selectSexo\">Sexo del empleador</label>
          <select class=\"col-md-6\" name=\"selectSexo\" id=\"selectSexo\">
            <option value=\"A0\">Selecione</option>
            <option value=\"0\">Femenino</option>
            <option value=\"1\">Masculino</option>
          </select>
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtCedula\">Cedula</label>
          <input class=\"col-md-6 \" type=\"number\" name=\"txtCedula\" id=\"txtCedula\" value=\"\" placeholder=\"Ingrese la cedula del empleador\">
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtTelefono\">Telefono</label>
          <input class=\"col-md-6\" type=\"number\" name=\"txtTelefono\" id=\"txtTelefono\" value=\"\" placeholder=\"Ingrese el telefono del empleador\">
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtDirrecion\">Dirrecion</label>
          <input class=\"col-md-6 \" type=\"text\" name=\"txtDirrecion\" id=\"txtDirrecion\" value=\"\" placeholder=\"Ingrese la dirrecion del empleador\">
        </div>
        <div class=\"col-md-10\">
          <label class=\"col-md-12\" for=\"txtFechaNacimiento\">Fecha nacimiento</label>
          <input class=\"col-md-6 \" type=\"date\" name=\"txtFechaNacimiento\" id=\"txtFechaNacimiento\" value=\"\" placeholder=\"Ingrese la fecha de nacimiento del empleador\"> 
  
        </div>
        <div class=\"col-md-6\">
            </br><button type=\"button\" class=\"btn btn-success\" id=\"btnAgregarEmpleador\">Agregar empleador</button>
        </div>
      </form>
  {% endblock%}
{%block javaScripts%}
  {{parent()}}
  <script src=\"{{asset('bundles/symplifica/js/empleador.js')}}\"> </script>

{%endblock%}", "SymplificaBundle:Empleador:EmpleadorAddView.html.twig", "/opt/lampp/htdocs/SymfonyPruebaT/symplifica/src/SymplificaBundle/Resources/views/Empleador/EmpleadorAddView.html.twig");
    }
}
