<?php

/* layout.html.twig */
class __TwigTemplate_6d1dd56f83cd02196aa4a30f1a717f8603ff0f1510a8752a272bbe9bf21edf46 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javaScripts' => array($this, 'block_javaScripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_72b93475a526548b4fbab8be3816cfaa5ac7c25d92e05a6d98533076069bc630 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_72b93475a526548b4fbab8be3816cfaa5ac7c25d92e05a6d98533076069bc630->enter($__internal_72b93475a526548b4fbab8be3816cfaa5ac7c25d92e05a6d98533076069bc630_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        $__internal_5f6f38108abe6df2ca374db7d0257592a8c44cfb29ab4da6c906e3972e0ea95a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5f6f38108abe6df2ca374db7d0257592a8c44cfb29ab4da6c906e3972e0ea95a->enter($__internal_5f6f38108abe6df2ca374db7d0257592a8c44cfb29ab4da6c906e3972e0ea95a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 10
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
       <article class=\"col-md-12\">
            <label >Menu</label></br>
        <a href=\"";
        // line 15
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("symplifica_empleador");
        echo "\">Creación de empleador</a> </br>
         <a href=\"";
        // line 16
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("symplifica_empleado");
        echo "\">Creación de empleado</a> </br>
          <a href=\"";
        // line 17
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("symplifica_reporte");
        echo "\">Reporte</a>


      </article>
        ";
        // line 21
        $this->displayBlock('body', $context, $blocks);
        // line 22
        echo "            <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/js/jquery1.js"), "html", null, true);
        echo "\"> </script>
            <script src=\"";
        // line 23
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/js/datatables.js"), "html", null, true);
        echo "\"> </script>
        ";
        // line 24
        $this->displayBlock('javaScripts', $context, $blocks);
        // line 25
        echo "    </body>
</html>
";
        
        $__internal_72b93475a526548b4fbab8be3816cfaa5ac7c25d92e05a6d98533076069bc630->leave($__internal_72b93475a526548b4fbab8be3816cfaa5ac7c25d92e05a6d98533076069bc630_prof);

        
        $__internal_5f6f38108abe6df2ca374db7d0257592a8c44cfb29ab4da6c906e3972e0ea95a->leave($__internal_5f6f38108abe6df2ca374db7d0257592a8c44cfb29ab4da6c906e3972e0ea95a_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_20b5c307343306440968c5bfafea6c4bacf8227382ce3dff4b42732625af648f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_20b5c307343306440968c5bfafea6c4bacf8227382ce3dff4b42732625af648f->enter($__internal_20b5c307343306440968c5bfafea6c4bacf8227382ce3dff4b42732625af648f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_9a051aa9d7517cfa6168118aafea4eab1c525cc54f09a3942393ed714a4812cf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_9a051aa9d7517cfa6168118aafea4eab1c525cc54f09a3942393ed714a4812cf->enter($__internal_9a051aa9d7517cfa6168118aafea4eab1c525cc54f09a3942393ed714a4812cf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Symplifica";
        
        $__internal_9a051aa9d7517cfa6168118aafea4eab1c525cc54f09a3942393ed714a4812cf->leave($__internal_9a051aa9d7517cfa6168118aafea4eab1c525cc54f09a3942393ed714a4812cf_prof);

        
        $__internal_20b5c307343306440968c5bfafea6c4bacf8227382ce3dff4b42732625af648f->leave($__internal_20b5c307343306440968c5bfafea6c4bacf8227382ce3dff4b42732625af648f_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_b35bec00278dddcab20db31c5c42267c75014159d43872a85fca6600e400c136 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b35bec00278dddcab20db31c5c42267c75014159d43872a85fca6600e400c136->enter($__internal_b35bec00278dddcab20db31c5c42267c75014159d43872a85fca6600e400c136_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_2384e24e1e751fe8f728298039edb3cf7397127b1d9065356352e93b3a0b30dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2384e24e1e751fe8f728298039edb3cf7397127b1d9065356352e93b3a0b30dc->enter($__internal_2384e24e1e751fe8f728298039edb3cf7397127b1d9065356352e93b3a0b30dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 7
        echo "            <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/bootstrap.min.css"), "html", null, true);
        echo "\">
            <link rel=\"stylesheet\" href=\"";
        // line 8
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("public/css/datatables.css"), "html", null, true);
        echo "\">
        ";
        
        $__internal_2384e24e1e751fe8f728298039edb3cf7397127b1d9065356352e93b3a0b30dc->leave($__internal_2384e24e1e751fe8f728298039edb3cf7397127b1d9065356352e93b3a0b30dc_prof);

        
        $__internal_b35bec00278dddcab20db31c5c42267c75014159d43872a85fca6600e400c136->leave($__internal_b35bec00278dddcab20db31c5c42267c75014159d43872a85fca6600e400c136_prof);

    }

    // line 21
    public function block_body($context, array $blocks = array())
    {
        $__internal_38f50c12f397709f6b42ca0607d80630344b9da85f903277cc8518d2ad8174cb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_38f50c12f397709f6b42ca0607d80630344b9da85f903277cc8518d2ad8174cb->enter($__internal_38f50c12f397709f6b42ca0607d80630344b9da85f903277cc8518d2ad8174cb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_ca3a6df56305af996ef7974c0f981a79de3275d2f66f170a684a29f68cc0ccfa = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ca3a6df56305af996ef7974c0f981a79de3275d2f66f170a684a29f68cc0ccfa->enter($__internal_ca3a6df56305af996ef7974c0f981a79de3275d2f66f170a684a29f68cc0ccfa_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_ca3a6df56305af996ef7974c0f981a79de3275d2f66f170a684a29f68cc0ccfa->leave($__internal_ca3a6df56305af996ef7974c0f981a79de3275d2f66f170a684a29f68cc0ccfa_prof);

        
        $__internal_38f50c12f397709f6b42ca0607d80630344b9da85f903277cc8518d2ad8174cb->leave($__internal_38f50c12f397709f6b42ca0607d80630344b9da85f903277cc8518d2ad8174cb_prof);

    }

    // line 24
    public function block_javaScripts($context, array $blocks = array())
    {
        $__internal_30954ae00e3e5a6ee505c7c87da8638417df9a4e93ca9cd4b8f473b9e599add0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_30954ae00e3e5a6ee505c7c87da8638417df9a4e93ca9cd4b8f473b9e599add0->enter($__internal_30954ae00e3e5a6ee505c7c87da8638417df9a4e93ca9cd4b8f473b9e599add0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javaScripts"));

        $__internal_8598a226775f67267252c865c1c9918611bd3cbdfd1443bda1191f0632005063 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8598a226775f67267252c865c1c9918611bd3cbdfd1443bda1191f0632005063->enter($__internal_8598a226775f67267252c865c1c9918611bd3cbdfd1443bda1191f0632005063_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javaScripts"));

        
        $__internal_8598a226775f67267252c865c1c9918611bd3cbdfd1443bda1191f0632005063->leave($__internal_8598a226775f67267252c865c1c9918611bd3cbdfd1443bda1191f0632005063_prof);

        
        $__internal_30954ae00e3e5a6ee505c7c87da8638417df9a4e93ca9cd4b8f473b9e599add0->leave($__internal_30954ae00e3e5a6ee505c7c87da8638417df9a4e93ca9cd4b8f473b9e599add0_prof);

    }

    public function getTemplateName()
    {
        return "layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  151 => 24,  134 => 21,  122 => 8,  117 => 7,  108 => 6,  90 => 5,  78 => 25,  76 => 24,  72 => 23,  67 => 22,  65 => 21,  58 => 17,  54 => 16,  50 => 15,  41 => 10,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Symplifica{% endblock %}</title>
        {% block stylesheets %}
            <link rel=\"stylesheet\" href=\"{{asset('public/css/bootstrap.min.css')}}\">
            <link rel=\"stylesheet\" href=\"{{asset('public/css/datatables.css')}}\">
        {% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
       <article class=\"col-md-12\">
            <label >Menu</label></br>
        <a href=\"{{path('symplifica_empleador')}}\">Creación de empleador</a> </br>
         <a href=\"{{path('symplifica_empleado')}}\">Creación de empleado</a> </br>
          <a href=\"{{path('symplifica_reporte')}}\">Reporte</a>


      </article>
        {% block body %}{% endblock %}
            <script src=\"{{asset('public/js/jquery1.js')}}\"> </script>
            <script src=\"{{asset('public/js/datatables.js')}}\"> </script>
        {% block javaScripts %}{% endblock %}
    </body>
</html>
", "layout.html.twig", "/opt/lampp/htdocs/SymfonyPruebaT/symplifica/app/Resources/views/layout.html.twig");
    }
}
