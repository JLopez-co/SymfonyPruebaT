<?php

/* SymplificaBundle:Reporte:ReporteSelectView.html.twig */
class __TwigTemplate_9ad9a5f8be45b0089c2210bf3010c0ba6b939cdcefb07f8090448a47e8b3973d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("layout.html.twig", "SymplificaBundle:Reporte:ReporteSelectView.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_23e7d5f97911f84ff897ad25f05f664c52b23f1e58b93098890e1b88edb7c093 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_23e7d5f97911f84ff897ad25f05f664c52b23f1e58b93098890e1b88edb7c093->enter($__internal_23e7d5f97911f84ff897ad25f05f664c52b23f1e58b93098890e1b88edb7c093_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SymplificaBundle:Reporte:ReporteSelectView.html.twig"));

        $__internal_318016a46bea60f2cb84741a4206b095926da7430d5012705092f98a947203dc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_318016a46bea60f2cb84741a4206b095926da7430d5012705092f98a947203dc->enter($__internal_318016a46bea60f2cb84741a4206b095926da7430d5012705092f98a947203dc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "SymplificaBundle:Reporte:ReporteSelectView.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_23e7d5f97911f84ff897ad25f05f664c52b23f1e58b93098890e1b88edb7c093->leave($__internal_23e7d5f97911f84ff897ad25f05f664c52b23f1e58b93098890e1b88edb7c093_prof);

        
        $__internal_318016a46bea60f2cb84741a4206b095926da7430d5012705092f98a947203dc->leave($__internal_318016a46bea60f2cb84741a4206b095926da7430d5012705092f98a947203dc_prof);

    }

    // line 2
    public function block_title($context, array $blocks = array())
    {
        $__internal_54f06796df827e80b5bba82042bf470084f7bb4677645c08803778643bcf223d = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_54f06796df827e80b5bba82042bf470084f7bb4677645c08803778643bcf223d->enter($__internal_54f06796df827e80b5bba82042bf470084f7bb4677645c08803778643bcf223d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e9db70b8edfe39100f127b6191081000a8b940eea49d4983af426a25bb266bea = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e9db70b8edfe39100f127b6191081000a8b940eea49d4983af426a25bb266bea->enter($__internal_e9db70b8edfe39100f127b6191081000a8b940eea49d4983af426a25bb266bea_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo " Symplifica-Reporte ";
        
        $__internal_e9db70b8edfe39100f127b6191081000a8b940eea49d4983af426a25bb266bea->leave($__internal_e9db70b8edfe39100f127b6191081000a8b940eea49d4983af426a25bb266bea_prof);

        
        $__internal_54f06796df827e80b5bba82042bf470084f7bb4677645c08803778643bcf223d->leave($__internal_54f06796df827e80b5bba82042bf470084f7bb4677645c08803778643bcf223d_prof);

    }

    // line 3
    public function block_body($context, array $blocks = array())
    {
        $__internal_35fa554eedbe6ab2047f31f6d073573c218241b7b5bdae9cbc1db86085780bc3 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_35fa554eedbe6ab2047f31f6d073573c218241b7b5bdae9cbc1db86085780bc3->enter($__internal_35fa554eedbe6ab2047f31f6d073573c218241b7b5bdae9cbc1db86085780bc3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_c75b8b374ff63e44299b8c056b0c2043d4dd0f907a8b29b6ff41f1bc69d1e9c6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_c75b8b374ff63e44299b8c056b0c2043d4dd0f907a8b29b6ff41f1bc69d1e9c6->enter($__internal_c75b8b374ff63e44299b8c056b0c2043d4dd0f907a8b29b6ff41f1bc69d1e9c6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 4
        echo "    <div class=\"col-md-12\">
      <table>
        <thead>
          <th>Nombre empleador</th>
          <th>Cedula empleador</th>
          <th>Dirrecion empleador</th>
          <th>Nombre empleado</th>
          <th>Cedula empleado</th>
          <th>Tipo contra</th>
        </thead>
      </table>
    </div>
  ";
        
        $__internal_c75b8b374ff63e44299b8c056b0c2043d4dd0f907a8b29b6ff41f1bc69d1e9c6->leave($__internal_c75b8b374ff63e44299b8c056b0c2043d4dd0f907a8b29b6ff41f1bc69d1e9c6_prof);

        
        $__internal_35fa554eedbe6ab2047f31f6d073573c218241b7b5bdae9cbc1db86085780bc3->leave($__internal_35fa554eedbe6ab2047f31f6d073573c218241b7b5bdae9cbc1db86085780bc3_prof);

    }

    public function getTemplateName()
    {
        return "SymplificaBundle:Reporte:ReporteSelectView.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  68 => 4,  59 => 3,  41 => 2,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends 'layout.html.twig'%}
{% block title %} Symplifica-Reporte {% endblock%}
  {% block body%}
    <div class=\"col-md-12\">
      <table>
        <thead>
          <th>Nombre empleador</th>
          <th>Cedula empleador</th>
          <th>Dirrecion empleador</th>
          <th>Nombre empleado</th>
          <th>Cedula empleado</th>
          <th>Tipo contra</th>
        </thead>
      </table>
    </div>
  {% endblock%}", "SymplificaBundle:Reporte:ReporteSelectView.html.twig", "/opt/lampp/htdocs/SymfonyPruebaT/symplifica/src/SymplificaBundle/Resources/views/Reporte/ReporteSelectView.html.twig");
    }
}
